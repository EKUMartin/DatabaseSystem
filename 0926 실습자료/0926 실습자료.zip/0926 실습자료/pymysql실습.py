import pymysql
import pandas as pd

# pd.read_csv

conn = pymysql.connect(
    host="localhost", user="root", password="1234", db="testdb", charset="utf8"
)

curs = conn.cursor()


# department 테이블에 데이터 insert
sql = "insert into department values(%s, %s, %s)"  # deptno, deptname, floor
curs.execute(sql, (1, "IT부", 3))

# employee 테이블에 데이터 insert
sql = "insert into employee values(%s, %s, %s, %s, %s, %s)"  # empno, empname, title, manager, salary, dno
curs.execute(sql, (1, "홍길동", "manager", None, 5000000, 1))
conn.commit()

####################################################################
#
# Department_Table.csv를 pd.read_csv를 이용하여 읽어와서 department 테이블에 데이터 insert
# Employee_Table.csv를 pd.read_csv를 이용하여 읽어와서 employee 테이블에 데이터 insert
#
####################################################################
# code 작성 #
